%SCRIPT WILL RUN AN INDOOR CANNABIS PRODUCTION MODEL FOR 1,011 U.S. LOCATIONS.
%RESULTS ARE PRINTED AS AN EXCEL FILE TITLED "OUTPUTS" IN THE FOLDER WHERE 
%THIS SCRIPT IS LOCATED. IT WILL CONTAIN GREENHOUSE GAS EMISSIONS, 
%ELECTRICITY REQUIRED, AND NATURAL GAS REQUIRED FOR EACH LOCATION

clc; clear all; close all;
% Extract data
Location = 'C:\Users\Utilisateur\Documents\MATLAB\Indoor_Cannabis_Analysis\TMY3\'; % folder where you have all TMY data
D = dir([Location,'\*.csv']); % copy this script to that directory, same folder as TMY
filenames = {D(:).name}.';
filesstring = string(filenames);
data = cell(length(D),1); % empty matrix
carbon = zeros(length(D),1);
Site = string(zeros(length(D),2));
Lat = zeros(length(D),1);
Long = zeros(length(D),1);
Electricity = zeros(length(D),10);
elecintensity = zeros(length(D),1);
ngintensity = zeros(length(D),1);
lca1 = zeros(length(D),1);
lca2 = zeros(length(D),1);
lca3 = zeros(length(D),1);
lca4 = zeros(length(D),1);
lca5 = zeros(length(D),1);
lca6 = zeros(length(D),1);
lca7 = zeros(length(D),1);
lca8 = zeros(length(D),1);
lca9 = zeros(length(D),1);
lca10 = zeros(length(D),1);
lca11 = zeros(length(D),1);
lca12 = zeros(length(D),1);
lca13 = zeros(length(D),1);
lca14 = zeros(length(D),1);
lca15 = zeros(length(D),1);
lca16 = zeros(length(D),1);
lca17 = zeros(length(D),1);
lca18 = zeros(length(D),1);
lca19 = zeros(length(D),1);
lca20 = zeros(length(D),1);
lca21 = zeros(length(D),1);
lca22 = zeros(length(D),1);
lca23 = zeros(length(D),1);
lca24 = zeros(length(D),1);
lca25 = zeros(length(D),1);
lca26 = zeros(length(D),1);
lca27 = zeros(length(D),1);
lca28 = zeros(length(D),1);
lca29 = zeros(length(D),1);
lca30 = zeros(length(D),1);
lca31 = zeros(length(D),1);
lca32 = zeros(length(D),1);
lca33 = zeros(length(D),1);
lca34 = zeros(length(D),1);
lca35 = zeros(length(D),1);
lca36 = zeros(length(D),1);
lca37 = zeros(length(D),1);

count = 0;

elec = readtable('vdb_Zipcodes.xlsx','ReadRowNames',false,'Range','A1:G1012','VariableNamingRule','preserve');
%added 'VariableNamingRule','preserve' or else code wouldn't work

for i = 1:99 %99 total location, 50 is Gander
    tic
    fullname = [Location filesep D(i).name];
    Coord = xlsread(fullname,1,'E1:F1'); % Extract coordinates
    Lat(i) = Coord(1); % Allocate latitude of site
    Long(i) = Coord(2);% Allocate longitude of site
    
    [~,Loc] = xlsread(fullname,1,'B1:C1'); % Read location
    Site(i,1) = Loc{1} ; % City or town
    Site(i,2) = Loc{2};  %State

    Data = xlsread(fullname,1,'AF3:AO8785'); % Extract data faster to do it all at once, this array needs to fit meteorological data csv files
    T_o = Data(:,1);
    
    RH = Data(:,7);
    Pamb = Data(:,10)/10;
    avePamb = mean(Pamb); %average Pressure in kPa for year
    
    A = Indoor_Model_Facility_LCAv5_VDB(T_o,RH,Pamb,avePamb,filesstring,i,elec);
%modified file name above
    
    carbon(i,:) = sum(A(:,4))-A(38,4)-A(39,4);
    elecintensity(i) = A(38,1); %all columns are the same value here
    ngintensity(i) = A(39,1);
    lca1(i) = A(1,1);
    lca2(i) = A(2,1);
    lca3(i) = A(3,1);
    lca4(i) = A(4,1);
    lca5(i) = A(5,1);
    lca6(i) = A(6,1);
    lca7(i) = A(7,1);
    lca8(i) = A(8,1);
    lca9(i) = A(9,1);
    lca10(i) = A(10,1);
    lca11(i) = A(11,1);
    lca12(i) = A(12,1);
    lca13(i) = A(13,1);
    lca14(i) = A(14,1);
    lca15(i) = A(15,1);
    lca16(i) = A(16,1);
    lca17(i) = A(17,1);
    lca18(i) = A(18,1);
    lca19(i) = A(19,1);
    lca20(i) = A(20,1);
    lca21(i) = A(21,1);
    lca22(i) = A(22,1);
    lca23(i) = A(23,1);
    lca24(i) = A(24,1);
    lca25(i) = A(25,1);
    lca26(i) = A(26,1);
    lca27(i) = A(27,1);
    lca28(i) = A(28,1);
    lca29(i) = A(29,1);
    lca30(i) = A(30,1);
    lca31(i) = A(31,1);
    lca32(i) = A(32,1);
    lca33(i) = A(33,1);
    lca34(i) = A(34,1);
    lca35(i) = A(35,1);
    lca36(i) = A(36,1);
    lca37(i) = A(37,1);

       
    count = count +1
    toc
end

% Write outputs into excel file
carbon = num2cell(carbon);
elecintensity = num2cell(elecintensity);
ngintensity = num2cell(ngintensity);
lca1 = num2cell(lca1);
lca2 = num2cell(lca2);
lca3 = num2cell(lca3);
lca4 = num2cell(lca4);
lca5 = num2cell(lca5);
lca6 = num2cell(lca6);
lca7 = num2cell(lca7);
lca8 = num2cell(lca8);
lca9 = num2cell(lca9);
lca10 = num2cell(lca10);
lca11 = num2cell(lca11);
lca12 = num2cell(lca12);
lca13 = num2cell(lca13);
lca14 = num2cell(lca14);
lca15 = num2cell(lca15);
lca16 = num2cell(lca16);
lca17 = num2cell(lca17);
lca18 = num2cell(lca18);
lca19 = num2cell(lca19);
lca20 = num2cell(lca20);
lca21 = num2cell(lca21);
lca22 = num2cell(lca22);
lca23 = num2cell(lca23);
lca24 = num2cell(lca24);
lca25 = num2cell(lca25);
lca26 = num2cell(lca26);
lca27 = num2cell(lca27);
lca28 = num2cell(lca28);
lca29 = num2cell(lca29);
lca30 = num2cell(lca30);
lca31 = num2cell(lca31);
lca32 = num2cell(lca32);
lca33 = num2cell(lca33);
lca34 = num2cell(lca34);
lca35 = num2cell(lca35);
lca36 = num2cell(lca36);
lca37 = num2cell(lca37);



Output = [filenames, Lat, Long, Site, num2cell(carbon), num2cell(elecintensity), num2cell(ngintensity), num2cell(lca1), num2cell(lca2)	, num2cell(lca3)	, num2cell(lca4)	, num2cell(lca5)	, num2cell(lca6)	, num2cell(lca7)	, num2cell(lca8)	, num2cell(lca9)	, num2cell(lca10)	, num2cell(lca11)	, num2cell(lca12)	, num2cell(lca13)	, num2cell(lca14)	, num2cell(lca15)	, num2cell(lca16)	, num2cell(lca17)	, num2cell(lca18)	, num2cell(lca19)	, num2cell(lca20)	, num2cell(lca21)	, num2cell(lca22)	, num2cell(lca23)	, num2cell(lca24)	, num2cell(lca25)	, num2cell(lca26)	, num2cell(lca27)	, num2cell(lca28)	, num2cell(lca29)	, num2cell(lca30)	, num2cell(lca31)	, num2cell(lca32)	, num2cell(lca33)	, num2cell(lca34)	, num2cell(lca35)	, num2cell(lca36), num2cell(lca37)];

xlswrite('Outputs.xlsx', Output, 1, 'A2:AS1012');

%changed array of output for seeing individual categories
