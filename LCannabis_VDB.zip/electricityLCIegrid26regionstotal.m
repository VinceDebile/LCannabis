function [ LCIelectricity ] = electricityLCIegrid26regionstotal(filesstring,i,elec)
%FUNCTION ASSIGNS ELECTRICITY
%Modified by VDB et al 2023 line 8: 1:99 instead of 1:1011


    TMY3Site = string(table2cell(elec(:,1)));

    for j = 1:99
        a(j) = strcmp(filesstring(i),TMY3Site(j));
        if a(j) == 1;
            LCIelectricity = elec(j,7); %2020 GHGs
        end
    end




